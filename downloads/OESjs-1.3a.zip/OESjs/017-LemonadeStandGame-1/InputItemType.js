var InputItemType = new cLASS({
  Name: "InputItemType",
  supertypeName: "ItemType",
  properties: {
    "purchasePrice": {range: "Decimal", label: "Purchase price per supply unit"}
  }
});