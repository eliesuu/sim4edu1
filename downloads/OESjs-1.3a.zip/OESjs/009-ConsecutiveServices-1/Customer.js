var Customer = new cLASS({
  Name: "Customer",
  shortLabel: "Cust",
  supertypeName: "oBJECT",
  properties: {
    "arrivalTime": { range: "NonNegativeInteger", label: "Arrival time",
        shortLabel: "arrT"}
  }
});
