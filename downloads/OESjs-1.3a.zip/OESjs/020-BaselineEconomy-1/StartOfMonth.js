/*******************************************************************************
 * Beginning of the Month event class
 * 
 * @copyright Copyright 2018 Brandenburg University of Technology, Germany
 * @license The MIT License (MIT)
 * @author Luis Gustavo Nardin
 * @author Gerd Wagner
 ******************************************************************************/
var StartOfMonth =
    new cLASS( {
      Name: "StartOfMonth",
      shortLabel: "BM",
      supertypeName: "eVENT",
      
      // Properties
      properties: {},
      
      // Methods
      methods: {
        "onEvent": function () {
          var followupEvents = [];
          var iHHs = cLASS["Household"].instances;
          var kHHs = Object.keys( iHHs );
          var iFirms = cLASS["Firm"].instances;
          var hh, firm, i;
          
          sim.modelVariables.month =
              Math.floor( this.occTime / sim.modelVariables.daysMonth ) + 1;
          
          if ( sim.modelVariables.verbose ) {
            console.log( "Start of Month " + sim.modelVariables.month );
          }
          
          // Firms
          Object.keys( iFirms ).forEach(
              function ( objId ) {
                firm = iFirms[objId];
                
                if ( sim.modelVariables.month > firm.startPlanning ) {
                  // Adjust the wage rate
                  firm.adjustWageRate( sim.modelVariables.month );
                  
                  // Open or close a job position
                  firm.adjustJobPositions( sim.modelVariables.month );
                  
                  // Adjust consumption goods price
                  firm.adjustConsumptionGoodPrice( sim.modelVariables.month,
                      sim.modelVariables.daysMonth );
                  
                  // Reset monthly demand
                  firm.resetMonthDemand();
                }
              } );
          
          // Households
          util.shuffleArray( kHHs );
          
          kHHs.forEach( function ( objId ) {
            hh = iHHs[objId];
            
            // Search for a cheaper vendor
            firm = hh.searchCheaperVendor();
            
            // Replaces a limiting vendor
            hh.searchDeliveryCapableVendor( firm );
            
            // Search for a (better) job
            if ( !hh.employed ) {
              hh.searchJob();
            } else {
              hh.searchBetterPaidJob();
            }
            
            // Calculate daily demand
            hh.decideConsumption( sim.modelVariables.daysMonth );
          } );
          
          return followupEvents;
        }
      }
    } );

StartOfMonth.recurrence = function () {
  return (sim.modelVariables.daysMonth);
};
