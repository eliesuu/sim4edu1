/*******************************************************************************
 * EachDay event class
 * 
 * @copyright Copyright 2018 Brandenburg University of Technology, Germany
 * @license The MIT License (MIT)
 * @author Luis Gustavo Nardin
 * @author Gerd Wagner
 ******************************************************************************/
var EachDay =
    new cLASS(
        {
          Name: "EachDay",
          shortLabel: "D",
          supertypeName: "eVENT",
          
          // Properties
          properties: {},
          
          // Methods
          methods: {
            "onEvent": function () {
              var followupEvents = [];
              var iHHs = cLASS["Household"].instances;
              var kHHs = Object.keys( iHHs );
              var iFirms = cLASS["Firm"].instances;
              var hh, firm;
              
              sim.modelVariables.day =
                  sim.modelVariables.daysMonth -
                      ((sim.modelVariables.month * sim.modelVariables.daysMonth) - this.occTime);
              
              if ( sim.modelVariables.verbose ) {
                console.log( "Day " + sim.modelVariables.day );
              }
              
              // Households Consume Consumption Goods
              util.shuffleArray( kHHs );
              
              kHHs.forEach( function ( objId ) {
                iHHs[objId].buyConsumptionGoods();
              } );
              
              // Firms Produce Consumption Goods
              Object.keys( iFirms ).forEach( function ( objId ) {
                iFirms[objId].produceConsumptionGoods();
              } );
              
              return followupEvents;
            }
          }
        } );

EachDay.recurrence = function () {
  return (1);
};
