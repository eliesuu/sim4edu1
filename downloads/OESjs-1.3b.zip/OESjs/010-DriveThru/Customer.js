var Customer = new cLASS({
  Name: "Customer",
  supertypeName: "oBJECT",
  properties: {
    "arrivalTime": { range: "NonNegativeInteger", label: "Arrival time",
        shortLabel: "arrT"}
  }
});
