var ServiceDesk = new cLASS({
  Name: "ServiceDesk",
  supertypeName: "oBJECT",
  properties: {
    "waitingCustomers": { range: "Customer", label: "Waiting customers",
      shortLabel: "queue", minCard: 0, maxCard: Infinity}
  }
});
ServiceDesk.serviceDuration = function () {
  var r = rand.uniformInt( 0, 99);
  if ( r < 10) return 1;         // probability 0.10
  else if ( r < 30) return 2;    // probability 0.20
  else if ( r < 60) return 3;    // probability 0.30
  else if ( r < 85) return 4;    // probability 0.25
  else if ( r < 95) return 5;    // probability 0.10
  else return 6;                 // probability 0.05
};