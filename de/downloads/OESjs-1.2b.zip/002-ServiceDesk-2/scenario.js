/*******************************************************
 * ServiceDesk-2 - An example of a discrete event simulation.
 * @copyright Copyright 2016 Gerd Wagner, BTU (Germany)
 * @author Gerd Wagner
 * @license The MIT License (MIT)
 ********************************************************/
/*******************************************************
 Simulation Parameters
********************************************************/
sim.scenario.simulationEndTime = 200;
sim.scenario.idCounter = 11;  // start value of auto IDs
//scenario.randomSeed = 5;  // optional
sim.scenario.createLog = false;
//scenario.suppressInitialStateUI = true;
/*******************************************************
 Simulation Model
********************************************************/
sim.model.name = "ServiceDesk-2";
sim.model.title = "A Service Queue Model with Mean Response Time Statistics";
sim.model.systemNarrative = "The customers arriving at a service desk " +
    "have to wait in a queue when the service desk is busy. Otherwise, when the queue is empty " +
    "and the service desk is not busy, they are immediately served by the service clerk. Whenever " +
    "a service is completed, the served customer departs and the next customer from the queue, " +
    "if there is any, will be served.";
sim.model.shortDescription = "A service queue model (one service and one queue) with one statistic: " +
    "the Mean Response Time, which is the average length of time a customer spends in the system from " +
    "arrival to departure. For recording their arrival time, individual customers are represented " +
    "explicitly in a waitingCustomers queue. The model includes two object types: ServiceDesk " +
    "and Customer, and two event types: CustomerArrival and CustomerDeparture.";
sim.model.objectTypes = ["ServiceDesk", "Customer"];
sim.model.eventTypes = ["CustomerArrival", "CustomerDeparture"];
sim.model.constraints = {
  "nonEmptyQueue-implies-DepartureEvt": function () {
    var departureEvtExists = sim.FEL.containsEventOfType("CustomerDeparture");
    if (sim.namedObjects["sd1"].queueLength > 0) return departureEvtExists;  // there must be a departure
    else return !departureEvtExists;  // there must not be a departure
  }
};
// meta data
sim.model.license = "CC BY-NC";
sim.model.creator = "Gerd Wagner";
sim.model.created = "2016-09-30";
sim.model.modified = "2016-10-01";

/*******************************************************
 Define Initial State
********************************************************/
sim.scenario.initialState.objects = {
  "1": {typeName: "ServiceDesk", name: "sd1", shortLabel:"sd1", waitingCustomers:[]}
};
sim.scenario.initialState.events = [
  {typeName: "CustomerArrival", occTime: 1, serviceDesk: 1}
];
/*
sim.scenario.setupInitialState = function () {
  var sD = new ServiceDesk({id: 1, queueLength: 0});
  var c = new Customer({id: 2, arrivalTime: 1});
  sim.addObject( sD);
  sim.addObject(c);
  sim.scheduleEvent( new CustomerArrival({occTime:1, serviceDesk: sD, customer: c}));
}
*/
/*******************************************************
 Define Output Statistics Variables
 ********************************************************/
sim.model.statistics = {
  "arrivedCustomers": {range:"NonNegativeInteger", label:"Arrived customers"},
  "departedCustomers": {range:"NonNegativeInteger", label:"Departed customers"},
  "cumulativeTimeInSystem": {range:"Decimal"},
  "meanTimeInSystem": { range: "Decimal",  label:"Time in system",
    computeOnlyAtEnd: true, decimalPlaces: 1, unit: "min",
    expression: function () {
      return sim.stat.cumulativeTimeInSystem / sim.stat.departedCustomers}
  }
};
