/*******************************************************
 * ServiceDesk-1 - An example of a discrete event simulation.
 * @copyright Copyright 2016 Gerd Wagner, BTU (Germany) + ODU (VA, USA)
 * @author Gerd Wagner
 * @license The MIT License (MIT)
 ********************************************************/
/*******************************************************
 Simulation Parameters
********************************************************/
//sim.scenario.name = "...";  // optional
//sim.scenario.title = "...";  // optional
sim.scenario.simulationEndTime = 200;
sim.scenario.randomSeed = 12345;  // optional
sim.scenario.createLog = true;
//sim.scenario.suppressInitialStateUI = true;
/*******************************************************
 Simulation Model
********************************************************/
sim.model.name = "ServiceDesk-1";
sim.model.title = "A Service Queue Model with Utilization and Maximum Queue Length Statistics";
sim.model.systemNarrative = "The customers arriving at a service desk have to wait in a queue " +
    "when the service desk is busy. Otherwise, when the queue is empty and the service desk is not busy, they are " +
    "immediately served by the service clerk. Whenever a service is completed, the served customer departs " +
    "and the next customer from the queue, if there is any, will be served.";
sim.model.shortDescription = "A service queue model (one service and one queue) with two statistics: " +
    "maximum queue length and service utilization. The model abstracts away from individual customers and from the " +
    "composition of the queue, which is only represented in terms of its length. The model includes one object type: " +
	"ServiceDesk, and two event types: CustomerArrival and CustomerDeparture.";
// meta data
sim.model.license = "CC BY-NC";
sim.model.creator = "Gerd Wagner";
sim.model.created = "2016-06-01";
sim.model.modified = "2016-10-20";

sim.model.time = "discrete";  // implies using only discrete random variables
sim.model.objectTypes = ["ServiceDesk"];
sim.model.eventTypes = ["CustomerArrival", "CustomerDeparture"];
sim.model.constraints = {
  "nonEmptyQueue-implies-DepartureEvt": function () {
    var departureEvtExists = sim.FEL.containsEventOfType("CustomerDeparture");
    if (sim.namedObjects["serviceDesk1"].queueLength > 0) return departureEvtExists;  // there must be a departure
    else return !departureEvtExists;  // there must not be a departure
  }
};

/*******************************************************
 Define Initial State
********************************************************/
// Either declaratively:
sim.scenario.initialState.objects = {
  "1": {typeName: "ServiceDesk", name:"serviceDesk1", shortLabel: "sd1", queueLength: 0}
};
sim.scenario.initialState.events = [
  {typeName: "CustomerArrival", occTime:1, serviceDesk: 1}
];
// Or with a procedure:
/*
sim.scenario.setupInitialState = function () {
  var sD = new ServiceDesk({id: 1, queueLength: 0, isBusy: false});
  sim.addObject( sD);
  sim.scheduleEvent( new CustomerArrival({occTime:1, serviceDesk: sD}));
}
*/
/*******************************************************
 Define Output Statistics Variables
 ********************************************************/
sim.model.statistics = {
  "arrivedCustomers": {range:"NonNegativeInteger", label:"Arrived customers"},
  "departedCustomers": {range:"NonNegativeInteger", label:"Departed customers"},
  "totalServiceTime": {range:"NonNegativeInteger"},
  "serviceUtilization": {range:"Decimal", label:"Service utilization",
      computeOnlyAtEnd: true, decimalPlaces: 1, unit: "%",
      expression: function () {
        return sim.stat.totalServiceTime / sim.time * 100
      }
  },
  "maxQueueLength": {objectType:"ServiceDesk", objectIdRef: 1,
      property:"queueLength", aggregationFunction:"max", label:"Max. queue length"},
  "averageQueueLength": {objectType:"ServiceDesk", objectIdRef: 1,
    property:"queueLength", aggregationFunction:"avg", label:"Avg. queue length"},
  "queueLength": {objectType:"ServiceDesk", objectIdRef: 1,
    property:"queueLength", showTimeSeries: true, label:"Queue length"}
};
/*******************************************************
 Define the observation UI
 ********************************************************/
sim.scenario.observationUI.type = "SVG";
sim.scenario.observationUI.canvas.width = 600;
sim.scenario.observationUI.canvas.height = 300;
sim.scenario.observationUI.canvas.style = "background-color:yellow";
sim.scenario.observationUI.fixedElements = {
  "serviceDesk1": {
    shapeName: "polygon",
    shapeAttributes: {points: "400,150 400,160 350,160 350,260 340,260 340,160 240,160 240,260 230,260 230,160 180,160 180,150"},
    style: "fill:brown; stroke-width:0"
  },
  "LemonadePitcher": {
    shapeName: "polyline",
    shapeAttributes: {points: "200,100 200,150 250,150 250,100"},
    style: "fill:none; stroke:black; stroke-width:3"
  }
};
sim.scenario.observationUI.objectViews = {
  "LemonadeStand": [  // a view consisting of a group of SVG elements
    {shapeName: "rect", style: "fill:yellow; stroke-width:0",
      shapeAttributes: { x: 205, width: 40,
        y: function (stand) {return 145 - stand.productType.stockQuantity;},
        height: function (stand) {return stand.productType.stockQuantity;}
      }
    },
    {shapeName: "rect", fillPatternImage:{id:"fp1", file:"Dollar-Coin.svg"}, style:"stroke-width:0",
      shapeAttributes: { x: 300, width: 60,
        y: function (stand) {return 145 - parseInt( stand.amountOfCash / 10);},
        height: function (stand) {return parseInt( stand.amountOfCash / 10);}
      }
    },
    {shapeName: "text", shapeAttributes: {x: 225, y: 145,
      textContent: function (stand) {return stand.productType.stockQuantity;}},
      style:"font-size:10px; text-anchor:middle"
    }
  ],
  "Market": {  // a view consisting of a map of enum attributes to lists of visualization items with an optional canvasBackgroundColor
    "weatherState": [  // an array list mapping enum indexes to visualization items
      {shapeName:"image", shapeAttributes:{ file:"icons8-Summer-96.png",
        x:450, y:0, width:96, height:96}, canvasBackgroundColor:"lightyellow"},
      {shapeName:"image", shapeAttributes:{ file:"icons8-Partly-Cloudy-Day-96.png",
        x:450, y:0, width:96, height:96}, canvasBackgroundColor:"oldlace"},  // or ivory?
      {shapeName:"image", shapeAttributes:{ file:"icons8-Cloud-128.png",
        x:450, y:0, width:128, height:128}, canvasBackgroundColor:"lightgray"},
      {shapeName:"image", shapeAttributes:{ file:"icons8-Rain-128.png",
        x:450, y:0, width:128, height:128}, canvasBackgroundColor:"silver"},
    ]
  }
};
sim.scenario.observationUI.eventAppearances = {
  "DailyDemand": {
    //sound: {duration: 1000, source:"12/300/80 14/200/90"},
    view: {  // an event view is a web animation of a DOM element
      imageFile: "customers.svg",
      style: "width:300px; height:300px; position:absolute; left:-30%; top:135px;",
      keyframes: [{left:'-30%'}, {left:'80%'}],
      duration: 1000,  // ms
      //iterations: Infinity,
      //fill:
    }
  },
  "EndOfDay": {
    view: {  // an event view is a web animation of a DOM element
      domElem: function () {return sim.visualEl;},  // the visualization container element
      keyframes: [{backgroundColor:'lightgray'}, {backgroundColor:'darkslategrey'}],
      duration: 1000  // ms
    }
  }
};
