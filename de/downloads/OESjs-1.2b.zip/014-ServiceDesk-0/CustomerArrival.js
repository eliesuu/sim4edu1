/*******************************************************************************
 * The CustomerArrival event class
 *
 * @copyright Copyright 2017 Gerd Wagner
 *   Chair of Internet Technology, Brandenburg University of Technology, Germany.
 * @license The MIT License (MIT)
 * @author Gerd Wagner
 ******************************************************************************/
var CustomerArrival = new cLASS({
  Name: "CustomerArrival",
  shortLabel: "Arr",  // for the log
  supertypeName: "eVENT",
  properties: {},
  methods: {
    "onEvent": function () {
      var events = [];
      sim.globalVars.queueLength++;  // increment global variable
      sim.stat.arrivedCustomers++;
      // if the service desk is not busy
      if (sim.globalVars.queueLength === 1) {
        events.push( new CustomerDeparture({
          occTime: this.occTime + sim.model.f.serviceDuration()
        }));
      }
      return events;
    }
  }
});
// Any exogenous event type needs to define a static function "recurrence"
CustomerArrival.recurrence = function () {
  return rand.uniformInt( 1, 6); 
};
// Any exogenous event type needs to define a static function "createNextEvent"
CustomerArrival.createNextEvent = function (e) {
 return new CustomerArrival({
     occTime: e.occTime + CustomerArrival.recurrence()
  });
};
