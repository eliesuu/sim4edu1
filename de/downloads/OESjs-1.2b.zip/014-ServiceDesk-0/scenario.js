/*******************************************************
 * ServiceDesk-1 - An example of a discrete event simulation.
 * @copyright Copyright 2016 Gerd Wagner, BTU (Germany) + ODU (VA, USA)
 * @author Gerd Wagner
 * @license The MIT License (MIT)
 ********************************************************/
/*******************************************************
 Simulation Parameters
********************************************************/
//sim.scenario.name = "...";  // optional
//sim.scenario.title = "...";  // optional
sim.scenario.simulationEndTime = 200;
sim.scenario.randomSeed = 12345;  // optional
sim.scenario.createLog = true;
//sim.scenario.suppressInitialStateUI = true;
/*******************************************************
 Simulation Model
********************************************************/
sim.model.name = "ServiceDesk-0";
sim.model.title = "A Service Queue Model with Queue Length Statistics";
sim.model.systemNarrative = "The customers arriving at a service desk have to wait in a queue " +
    "when the service desk is busy. Otherwise, when the queue is empty and the service desk is not busy, they are " +
    "immediately served by the service clerk. Whenever a service is completed, the served customer departs " +
    "and the next customer from the queue, if there is any, will be served.";
sim.model.shortDescription = "A service queue model (one service and one queue) with two statistics: " +
    "maximum queue length and average queue length. The model abstracts away from individual customers and from the " +
    "composition of the queue, which is only represented in terms of its length as the value of a global variable " +
    "'queueLength'. The model includes two event types: CustomerArrival and CustomerDeparture.";
// meta data
sim.model.license = "CC BY-NC";
sim.model.creator = "Gerd Wagner";
sim.model.created = "2017-10-30";
sim.model.modified = "2017-10-30";

sim.model.time = "discrete";  // implies using only discrete random variables
sim.model.eventTypes = ["CustomerArrival", "CustomerDeparture"];
// global variable
sim.model.v.queueLength = {range:"NonNegativeInteger", shortLabel:"qLen", initialValue: 0};
// global function
sim.model.f.serviceDuration = function () {
  var r = rand.uniformInt( 0, 99);
  if ( r < 30) return 2;         // probability 0.30
  else if ( r < 80) return 3;    // probability 0.50
  else return 4;                 // probability 0.20
};

/*******************************************************
 Define Initial State
********************************************************/
// Either declaratively:
sim.scenario.initialState.events = [
  {typeName: "CustomerArrival", occTime:1, serviceDesk:"1"}
];
// Or with a procedure:
/*
sim.scenario.setupInitialState = function () {
  var sD = new ServiceDesk({id: 1, queueLength: 0, isBusy: false});
  sim.addObject( sD);
  sim.scheduleEvent( new CustomerArrival({occTime:1, serviceDesk: sD}));
}
*/
/*******************************************************
 Define Output Statistics Variables
 ********************************************************/
sim.model.statistics = {
  "arrivedCustomers": {range:"NonNegativeInteger", label:"Arrived customers"},
  "departedCustomers": {range:"NonNegativeInteger", label:"Departed customers"},
  "maxQueueLength": {globalVariable:"queueLength", label:"Max. queue length",
      aggregationFunction:"max"},
  "averageQueueLength": {globalVariable:"queueLength", label:"Avg. queue length",
      aggregationFunction:"avg", decimalPlaces: 2},
  "queueLength": {globalVariable:"queueLength", showTimeSeries: true, label:"Queue length"}
};
