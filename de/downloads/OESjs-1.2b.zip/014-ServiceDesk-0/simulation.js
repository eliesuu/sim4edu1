/*******************************************************
 * ServiceDesk-1 - An example of a discrete event simulation.
 * @copyright Copyright 2016 Gerd Wagner, BTU (Germany) + ODU (VA, USA)
 * @author Gerd Wagner
 * @license The MIT License (MIT)
 ********************************************************/
/*******************************************************
 Simulation Parameters
********************************************************/
sim.scenario.simulationEndTime = 200;
sim.scenario.randomSeed = 12345;  // optional
sim.scenario.createLog = true;
/*******************************************************
 Simulation Model
********************************************************/
sim.model.name = "ServiceDesk-0";
sim.model.title = "A Service Queue Model with Utilization and Maximum Queue Length Statistics";
sim.model.systemNarrative = "The customers arriving at a service desk have to wait in a queue " +
    "when the service desk is busy. Otherwise, when the queue is empty and the service desk is not busy, " +
    "they are immediately served by the service clerk. Whenever a service is completed, the served " +
    "customer departs and the next customer from the queue, if there is any, will be served.";
sim.model.shortDescription = "A service queue model (one service and one queue) with two statistics: " +
    "maximum queue length and service utilization. For simplicity, the model uses abstract (discrete) "+
	"time and assumes that there is only one service desk, which does not have to be represented explicitly. "+
    "It also abstracts away from individual customers and from the composition of the queue, " +
    "which is only represented in terms of its length. The model includes two event types " +
	"(CustomerArrival and CustomerDeparture) and two discrete random time variables: one for "+
    "the recurrence of customer arrival events and one for modeling the duration of services.";
// meta data
sim.model.license = "CC BY-NC";
sim.model.creator = "Gerd Wagner";
sim.model.created = "2017-04-20";
sim.model.modified = "2017-04-20";

sim.model.time = "discrete";  // implies using only discrete random time variables
sim.model.eventTypes = ["CustomerArrival", "CustomerDeparture"];

// global variables
sim.model.v.queueLength = 0;
// global functions
sim.model.f.serviceDuration = function () {
    var r = rand.uniformInt( 0, 99);
    if ( r < 30) return 2;         // probability 0.30
    else if ( r < 80) return 3;    // probability 0.50
    else return 4;                 // probability 0.20
};
/*******************************************************
 Define Initial State
********************************************************/
sim.scenario.initialState.events = [
  {typeName: "CustomerArrival", occTime:1, serviceDesk:"1"}
];
