/*******************************************************
 * ServiceDesk-3 - An example of a discrete event simulation.
 * @copyright Copyright 2016 Gerd Wagner, BTU (Germany) + ODU (VA, USA)
 * @author Gerd Wagner
 * @license The MIT License (MIT)
 ********************************************************/
/*******************************************************
 Simulation Parameters
********************************************************/
//scenario.name = "...";  // optional
//scenario.title = "...";  // optional
sim.scenario.simulationEndTime = 200;
//sim.scenario.randomSeed = 12345;  // optional
sim.scenario.createLog = true;
//sim.scenario.suppressInitialStateUI = true;
/*******************************************************
 Simulation Model
********************************************************/
sim.model.name = "ServiceDesk-3";
sim.model.title = "An Activity-Based Service Queue Model";
sim.model.systemNarrative = "The customers arriving at a service desk (or service station) have to wait " +
    "in a queue when the service desk is busy. Otherwise, when the queue is empty and the service desk is not busy, " +
    "they are immediately served by the service clerk. Whenever a service is completed, the served customer " +
    "departs and the next customer from the queue, if there is any, will be served.";
sim.model.shortDescription = "A service queue model where the service is modeled as an activity with " +
    "the service desk as its resource, for which the utilization statistics is computed automatically. " +
    "The model includes one object type: ServiceDesk, one event type: CustomerArrival " +
    "and one activity type: PerformService.";
sim.model.objectTypes = ["ServiceDesk"];
sim.model.eventTypes = ["CustomerArrival"];
sim.model.activityTypes = ["PerformService"];

// meta data
sim.model.license = "CC BY-NC";
sim.model.creator = "Gerd Wagner";
sim.model.created = "2016-10-04";
sim.model.modified = "2016-10-18";
/*******************************************************
 Define Initial State
********************************************************/
sim.scenario.initialState.objects = {
  "1": {typeName: "ServiceDesk", name:"sd1", shortLabel:"sd1", queueLength: 0}
};
sim.scenario.initialState.events = [
  {typeName: "CustomerArrival", occTime:1, serviceDesk:"1"}
];
/*******************************************************
 Define Output Statistics Variables
 ********************************************************/
sim.model.statistics = {
  "arrivedCustomers": {range:"NonNegativeInteger", label:"Arrived customers"},
  "departedCustomers": {range:"NonNegativeInteger", label:"Departed customers"},
  "maxQueueLength": {objectType:"ServiceDesk", objectIdRef: 1,
      property:"queueLength", aggregationFunction:"max", label:"Max. queue length"}
};
