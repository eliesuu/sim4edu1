/*******************************************************
 * Gossip - An example of a discrete event simulation.
 * @copyright Copyright 2016 Gerd Wagner, BTU (Germany) + ODU (VA, USA)
 * @author Gerd Wagner
 * @license The MIT License (MIT)
********************************************************/

/*******************************************************
 Simulation Parameters
********************************************************/
sim.scenario.simulationEndTime = 100;
sim.scenario.stepDuration = 200;  // 200 ms observation time per step
sim.scenario.visualize = true;
/*******************************************************
 Simulation Model
********************************************************/
sim.model.name = "Gossip";
sim.model.title = "A Cellular Automata Model for the Problem of Spreading Gossip";
sim.model.systemNarrative = "People living in some area participate in the spread of gossip. " +
    "Each person learns of the gossip from a neighbour who has already heard the news, and may then " +
    "pass it on to his or her neighbour (but if they don’t happen to see their neighbour that day, " +
    "they will not have a chance to spread the news). Once someone hears the gossip, he or she " +
    "remembers it and does not need to hear it again.";
sim.model.shortDescription = "A cellular automata model where each cell represents a person "+
  "that is likely to spread the gossip to his or her neighbors (using the N/E/S/W concept of neighborhood). " +
    "Each cell may be in either of two states: knowing the gossip or not knowing about it, corresponding to " +
    "the two integer values 1 or 0 in an integer grid. If the cell is in state 0, and it has one or more " +
    "neighbours in state 1, then for each of them, change the cell's state to 1 with some probability, " +
    "otherwise leave it at 0. If the cell is in state 1, it remains in that state.";
// Space model
sim.model.space.type = "IntegerGrid";
sim.model.space.xMax = 100;
sim.model.space.yMax = 100;
// meta data
sim.model.license = "CC BY-NC";
sim.model.creator = "Gerd Wagner";
sim.model.created = "2016-11-30";
sim.model.modified = "2016-12-05";

sim.model.f.sampleGossipSpreadProbability = function () {
  return rand.uniformInt( 0, 1);  // for creating a 50% probability
};
/**
 * Check all 4 neighbor cells (N/E/S/W) if their value is 1
 */
sim.model.f.getNmrOfGossipNeighbors = function (x,y) {
  var nmrOfGossipNeighbors=0;
  // check North neighbor
  if (oes.space.grid.i.getCellValue( x, y+1) === 1) {
    nmrOfGossipNeighbors += 1;
  }
  // check East neighbor
  if (oes.space.grid.i.getCellValue( x+1, y) === 1) {
    nmrOfGossipNeighbors += 1;
  }
  // check South neighbor
  if (oes.space.grid.i.getCellValue( x, y-1) === 1) {
    nmrOfGossipNeighbors += 1;
  }
  // check West neighbor
  if (oes.space.grid.i.getCellValue( x-1, y) === 1) {
    nmrOfGossipNeighbors += 1;
  }
  return nmrOfGossipNeighbors;
};

sim.model.OnEachTimeStep = function () {
  var xMax = sim.model.space.xMax,
      yMax = sim.model.space.yMax;
  oes.space.grid.forAllCells( function (x,y) {
    var nmrOfGossipNeighbors = sim.model.f.getNmrOfGossipNeighbors(x,y),
        i = 0;
    for (i=0; i < nmrOfGossipNeighbors; i=i+1) {
      if (sim.model.f.sampleGossipSpreadProbability() === 1) {
        oes.space.grid.i.setCellValue( xMax-x+1, yMax-y+1, 1);
        break;
      }
    }
  });
};
/**********************************************************
 Define the initial state of the simulation 
***********************************************************/
sim.scenario.setupInitialState = function () {
  var xMax = sim.model.space.xMax,
      yMax = sim.model.space.yMax,
      xInitialGossip = Math.round( xMax/2),
      yInitialGossip = Math.round( yMax/2);
  oes.space.grid.i.setCellValue( xInitialGossip, yInitialGossip, 1);
};
