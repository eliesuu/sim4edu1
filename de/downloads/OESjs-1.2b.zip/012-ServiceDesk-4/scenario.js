/*******************************************************
 * ServiceDesk-3 - An example of a discrete event simulation.
 * @copyright Copyright 2016 Gerd Wagner, BTU (Germany) + ODU (VA, USA)
 * @author Gerd Wagner
 * @license The MIT License (MIT)
 ********************************************************/
/*******************************************************
 Simulation Parameters
********************************************************/
sim.scenario.simulationEndTime = 200;
sim.scenario.idCounter = 11;  // start value of auto IDs
//sim.scenario.randomSeed = 2345;  // optional
sim.scenario.createLog = true;
sim.scenario.suppressInitialStateUI = true;
/*******************************************************
 Simulation Model
********************************************************/
sim.model.name = "ServiceDesk-4";
sim.model.title = "A Processing Network Model of a Service Desk";
sim.model.systemNarrative = "The customers arriving at a service desk (or service station) " +
    "have to wait in a queue when the service desk is busy. Otherwise, when the queue is empty " +
    "and the service desk is not busy, they are immediately served by the service clerk. " +
    "Whenever a service is completed, the served customer departs and the next customer from " +
    "the queue, if there is any, will be served.";
sim.model.shortDescription = "The service desk is modeled as a processing node of a " +
    "processing network that has an entry node and an exit node for arriving and departing " +
    "customers. The model is based on the pre-defined Processing Network concepts eNTRYnODE, " +
    "pROCESSINGnODE and eXITnODE, such that work objects 'flow through the system' " +
    "by entering it through an arrival event at an entry node, then passing one or more " +
    "processing nodes while participating in their processing activities, and finally " +
    "leaving it through a departure event at an exit node. The simulation scenario just " +
    "instantiates one entry node, one processing node (the 'serviceDesk') and one exit " +
    "node.";
// meta data
sim.model.license = "CC BY-NC";
sim.model.creator = "Gerd Wagner";
sim.model.created = "2016-12-27";
sim.model.modified = "2017-01-04";

/**
 * Modeling event recurrence and activity durations as continuous random variables
 * requires using a continuous time model with the option to round the simulation time by
 * defining the model parameter timeRoundingFactor. By default, the timeRoundingFactor
 * also determines the model parameter nextMomentDeltaT, which is the minimal time delay
 * until the next moment (corresponding to the concept of simulation time granularity).
 * Otherwise, nextMomentDeltaT can be set explicitly, as shown below.
 *
 */
sim.model.time = "continuous";
// sim.model.timeRoundingDecimalPlaces = 3;  // like in 3.752
sim.model.nextMomentDeltaT = 0.001;


/*******************************************************
 Define Initial State
********************************************************/
sim.scenario.initialState.objects = {
  "1": {typeName: "eNTRYnODE", name:"custEntry", successorNode: 2},
  "2": {typeName: "pROCESSINGnODE", name:"serviceDesk", successorNode: 3},
  "3": {typeName: "eXITnODE", name:"custExit"}
};

