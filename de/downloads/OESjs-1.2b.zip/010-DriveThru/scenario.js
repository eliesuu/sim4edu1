/*******************************************************
 * ServiceDesk-3 - An example of a discrete event simulation.
 * @copyright Copyright 2016 Gerd Wagner, BTU (Germany) + ODU (VA, USA)
 * @author Gerd Wagner
 * @license The MIT License (MIT)
 ********************************************************/
/*******************************************************
 Simulation Parameters
********************************************************/
sim.scenario.simulationEndTime = 4*3600;
sim.scenario.timeUnit = "s";
sim.scenario.idCounter = 11;  // start value of auto IDs
//sim.scenario.randomSeed = 2345;  // optional
sim.scenario.createLog = false;
//sim.scenario.suppressInitialStateUI = true;
/*******************************************************
 Simulation Model
********************************************************/
sim.model.name = "DriveThru";
sim.model.title = "Drive Through Restaurant";
sim.model.systemNarrative = "<p>As a car enters the drive thru from the street, the driver decides "+
    "whether or not to get in line. If she decides to leave the restaurant, she counts as a lost customer. "+
    "If she decides to get in line, she waits until the menu board is available. At that time, she gives "+
    "the order to the order taker. After the order is taken, two things occur simultaneously:</p>"+
    "<ol><li>the driver moves forward if there is room, otherwise she has to wait at the menu board "+
     "until there is room to move forward.</li>"+
    "<li>The order is sent back to the kitchen where it is prepared with some delay.</li></ol>"+
    "<p>As soon as the driver reaches the pickup window, she pays and picks up her food, if it is ready. "+
    "If the food is not yet ready, she has to wait until her order is delivered to the pickup window.</p>";
sim.model.shortDescription = "The drive thru is modeled as a system with order processing "+
    "activities performed at three service points with queues: the order taking at the menu board, " +
    "the order preparation at the kitchen and the order pickup at the pickup window. The model includes " +
    "four object types: MenuBoard, Kitchen, PickupWindow and Customer, one event type: " +
    "CustomerArrival, and three activity types: OrderTaking, OrderPreparation and OrderPickup.";
// meta data
sim.model.source = "<a href='http://www.informs-sim.org/wsc08papers/005.pdf'>Introduction to Simulation</a> " +
    "by R.G. Ingalls, in <em>Proceedings of the 2008 Winter Simulation Conference</em>";
sim.model.license = "CC BY-NC";
sim.model.creator = "Gerd Wagner";
sim.model.created = "2016-12-07";
sim.model.modified = "2016-12-12";

sim.model.objectTypes = ["Customer", "MenuBoard", "Kitchen", "PickupWindow"];
sim.model.eventTypes = ["CustomerArrival"];
sim.model.activityTypes = ["OrderTaking", "OrderPreparation", "OrderPickup"];

sim.model.f.twoDice = function () {
  return rand.uniformInt(1,6) + rand.uniformInt(1,6)
};

/*******************************************************
 Define Initial State
********************************************************/
sim.scenario.initialState.objects = {
  "1": {typeName: "MenuBoard", name:"mb", maxLineSize: 3,
        waitingCustomers:[], kitchen: 2, pickupWindow: 3},
  "2": {typeName: "Kitchen", name:"ki",
        waitingOrders:[], pickupWindow: 3},
  "3": {typeName: "PickupWindow", name:"pw", maxLineSize: 3,
        waitingCustomers:[], preparedOrders:[], menuBoard: 1}
};
sim.scenario.initialState.events = [
  {typeName: "CustomerArrival", occTime: 1, menuBoard: 1}
];
/*******************************************************
 Define Output Statistics Variables
 ********************************************************/
sim.model.statistics = {
  "lostCustomers": {range:"NonNegativeInteger", label:"Lost customers"},
  "arrivedCustomers": {range:"NonNegativeInteger", label:"Arrived customers"},
  "departedCustomers": {range:"NonNegativeInteger", label:"Departed customers"},
  "revenue": { range: "Decimal", label:"Revenue", unit: "$"},
  "lostRevenue": { range: "Decimal", label:"Lost revenue", unit: "$"},
  "cumulativeTimeInSystem": {range:"Decimal"},
  "meanTimeInSystem": { range: "Decimal",  label:"Time in system",
    computeOnlyAtEnd: true, decimalPlaces: 1, unit: "s",
    expression: function () {
      return sim.stat.cumulativeTimeInSystem / sim.stat.departedCustomers}
  }
};
