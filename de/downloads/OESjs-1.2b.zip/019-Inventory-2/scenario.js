/*******************************************************
 * Inventory Management - An example of a discrete event simulation.
 * @copyright Copyright 2016 Gerd Wagner, BTU (Germany) + ODU (VA, USA)
 * @author Gerd Wagner
 * @license The MIT License (MIT)
********************************************************/
/*******************************************************
 General Variables and Methods
********************************************************/

/*******************************************************
 Simulation Parameters
********************************************************/
sim.scenario.simulationEndTime = 100;
//sim.scenario.randomSeed = 5;  // optional
sim.scenario.createLog = true;

/*******************************************************
 Simulation Model
********************************************************/
sim.model.name = "InventoryManagement-withPeriodicReplenishment";
sim.model.title = "Inventory Management with a Periodic Replenishment Policy";
sim.model.systemNarrative = "<p>A shop is selling one product type only (e.g., one model of TVs), " +
    "such that its in-house inventory only consists of items of that type. On each business day, " +
    "customers come to the shop and place their orders. If the ordered product quantity is in stock, " +
    "the customer pays for the order and the ordered products are provided. Otherwise, the shop has missed " +
    "a business opportunity and the difference bteween order quantity and the inventory level counts as a " +
    "lost sale. The order may still be partially fulfilled, if there are still some items in stock, else " +
    "the customer has to leave the shop without any item. The percentage of lost sales is an important " +
    "performance indicator.</p>" +
    "<p>Whenever the reorder interval has passed, the shop places a replenishment order with a quantity " +
    "computed as the difference between an upper threshold (called <i>target inventory</i>) " +
    "and the current inventory level.</p>";
sim.model.shortDescription = "<p>The model defines an inventory management system for a " +
    "single product shop with a periodic replenishment policy. For simplicity, " +
    "customer orders are treated in an abstract way by aggregating all of them into a daily demand event, " +
    "such that the random variation of the daily order quantity is modeled by a random variable.</p>" +
    "<p>Likewise, the random variation of the <i>delivery lead time</i>, which is the time in-between a " +
    "replenishment order and the corresponding delivery, is modeled by a random variable.</p>";
sim.model.objectTypes = ["SingleProductShop"];
sim.model.eventTypes = ["DailyDemand", "Delivery"];
// meta data
sim.model.license = "CC BY-NC";
sim.model.creator = "Gerd Wagner";
sim.model.created = "2016-06-01";
sim.model.modified = "2016-11-14";

/*******************************************************
 Define the initial state
 ********************************************************/
// Either declaratively:
sim.scenario.initialState.objects = {
  "1": {typeName: "SingleProductShop", name:"TV Shop",
    quantityInStock: 80, reorderInterval: 4, targetInventory: 100}
};
sim.scenario.initialState.events = [
  {typeName: "DailyDemand", occTime:1, quantity:25, shop:"1"}
];
// Or with a procedure:
/*
sim.scenario.setupInitialState = function () {
  var tvShop = new SingleProductShop({
    id: 1, name:"TV",
    quantityInStock: 80,
    reorderLevel: 50,
    targetInventory: 100
  });
  sim.addObject( tvShop);
  sim.scheduleEvent( new DailyDemand({occTime:1, quantity:25, shop: tvShop}));
}
*/
/*******************************************************
 Define Output Statistics Variables
 ********************************************************/
sim.model.statistics = {
  "lostSales": {range:"NonNegativeInteger", label:"Lost"},
  "averageInventory": {objectType:"SingleProductShop", objectIdRef: 1,
    property:"quantityInStock", aggregationFunction:"avg", label:"Avg. inventory"}
};
