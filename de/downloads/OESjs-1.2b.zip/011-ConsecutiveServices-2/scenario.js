/*******************************************************
 * ProcessingNetwork-1 - An example of an OES Processing Network simulation.
 * @copyright Copyright 2016 Gerd Wagner, BTU (Germany) + ODU (VA, USA)
 * @author Gerd Wagner
 * @license The MIT License (MIT)
 ********************************************************/
/*******************************************************
 Simulation Parameters
********************************************************/
sim.scenario.simulationEndTime = 300;
sim.scenario.idCounter = 11;  // start value of auto IDs
sim.scenario.randomSeed = 2345;  // optional
sim.scenario.createLog = true;
sim.scenario.suppressInitialStateUI = true;
/*******************************************************
 Simulation Model
********************************************************/
sim.model.name = "ProcessingNetwork-1";
sim.model.title = "A Processing Network Model of Two Consecutive Services";
sim.model.systemNarrative = "The customers of the Department of Motor Vehicles first have to " +
    "queue up at the reception for their request being recorded. Then they have to wait for a " +
    "clerk who will handle their case.";
sim.model.shortDescription = "Both the reception desk and the case handling desk are " +
    "modeled as processing nodes (with input queues) within a processing network that has " +
    "an entry node and an exit node for arriving and departing customers. The model is " +
    "based on the pre-defined OES Processing Network concepts eNTRYnODE, pROCESSINGnODE and " +
    "eXITnODE, such that work objects are 'flowing through the system' by entering it " +
    "through an arrival event at an entry node, then passing one or more processing nodes while " +
    "participating in their processing activities, and finally leaving it through a departure event " +
    "at an exit node. The simulation scenario just instantiates one entry node, two processing nodes " +
    "('receptDesk' and 'caseDesk') and one exit node.";
// meta data
sim.model.license = "CC BY-NC";
sim.model.creator = "Gerd Wagner";
sim.model.created = "2016-12-15";
sim.model.modified = "2016-12-27";

sim.model.time = "continuous";
sim.model.timeRoundingDecimalPlaces = 2;  // like in 3.85

/*******************************************************
 Define Initial State
********************************************************/
sim.scenario.initialState.objects = {
  "1": {typeName: "eNTRYnODE", name:"custEntry", successorNode: 2, maxNmrOfArrivals: 100},
  "2": {typeName: "pROCESSINGnODE", name:"receptDesk", successorNode: 3},
  "3": {typeName: "pROCESSINGnODE", name:"caseDesk", successorNode: 4,
        // define a non-default duration
        randomDuration: function () {return rand.exponential( 1);}},
  "4": {typeName: "eXITnODE", name:"custExit"}
};
