/*******************************************************
 * OESjs Simulation "LemonadeStand"
 * @copyright CC BY-NC 2017 Gerd Wagner
 ********************************************************/

/*******************************************************
 Simulation Parameters
 ********************************************************/
sim.scenario.simulationEndTime = 500;
sim.scenario.stepDuration = 1000; // ms
// sim.scenario.randomSeed = 5  // optional
sim.scenario.createLog = false;
sim.scenario.visualize = true;

//sim.scenario.artworkCredits = "Weather icons by <a href='https://icons8.com'>Icons8</a>";
sim.scenario.artworkCredits = "Weather icons by https://icons8.com";

/*******************************************************
 Simulation Model
 ********************************************************/
sim.model.name = "LemonadeStand-2";
sim.model.title = "A Lemonade Stand as a Manufacturing Company Subject to Weather Conditions";
sim.model.systemNarrative =
    "First of all, a company must check the inventory and decides how many " +
    "lemon+water+ice cubes+sugar need to purchasing as replenishment. Then " +
    "company starts to produce lemonade based on the demand forecasting and " +
    "total amount of inventory. During the production, the number of " +
    "inventory items will be reduced in order to create lemonade quantity. " +
    "After production company sells lemonade to customers until the end of " +
    "sales time or until all products have been sold.";
sim.model.shortDescription = "<p>This model is based on an.</p>";
// meta data
sim.model.license = "CC BY-NC";
sim.model.creator = "Gerd Wagner";
sim.model.contributors = "Ke Xu";
sim.model.created = "2017-09-19";
sim.model.modified = "2017-11-03";

sim.model.time = "discrete"; // implies using only discrete random variables
sim.model.timeUnit = "h";
sim.model.interactive = "true";

sim.model.objectTypes =
    ["SingleProductCompany", "ItemType", "InputItemType", "OutputItemType", "LemonadeMarket"];
sim.model.eventTypes =
    ["StartOfDay", "Delivery", "DailyDemand", "EndOfDay"];

/*******************************************************
 Define the initial state
 ********************************************************/
sim.scenario.initialState.objects = {
  "1": {
    typeName: "SingleProductCompany",
    name: "LemonadeStand",
    shortLabel: "Stand",
    productType: "2",  // Lemonade
    inputInventoryItems: {
      "Lemon": 80,  // pieces
      "Water": 80,  // liters
      "IceCubes": 800,  // pieces
      "Sugar": 10  // kilograms
    },
    currentReplenishmentOrder: {
      "Lemon": 0,
      "Water": 0,
      "IceCubes": 0,
      "Sugar": 0
    },
    amountOfCash: 500
  },
  "2": {
    typeName: "OutputItemType",
    name: "Lemonade",
    shortLabel: "Lem",
    quantityUnit: "Litre",
    supplyUnit: "cup",
    quantityPerSupplyUnit: 0.25,
    salesPrice: 1.5,  // e.g., USD
    batchSize: 3.5,  // 1 pitcher = 3.5 liters
    productionCost: 10,
    plannedProductionQuantity: 0,
    stockQuantity: 0,  // in quantityUnit
    bomItemsPerBatch: {"Lemon": 3, "Water": 2.5, "IceCubes": 50, "Sugar": 0.3}
  },
  "3": {
    typeName: "InputItemType",
    name: "Lemon",
    quantityUnit: "piece",
    supplyUnit: "bag",
    quantityPerSupplyUnit: 5,  // pieces
    purchasePrice: 2,  // per box
    targetInventory: 100  // pieces
  },
  "4": {
    typeName: "InputItemType",
    name: "Water",
    quantityUnit: "Litre",
    supplyUnit: "bottle",
    quantityPerSupplyUnit: 1.5,  // litre
    purchasePrice: 1,  // per bottle
    targetInventory: 100  // litre
  },
  "5": {
    typeName: "InputItemType",
    name: "IceCubes",
    quantityUnit: "piece",
    supplyUnit: "bag",
    quantityPerSupplyUnit: 100,// pieces
    purchasePrice: 2,
    targetInventory: 1000
  },
  "6": {
    typeName: "InputItemType",
    name: "Sugar",
    quantityUnit: "kilogram",
    supplyUnit: "bag",
    quantityPerSupplyUnit: 1,
    purchasePrice: 1,
    targetInventory: 15
  },
  "7": {
    typeName: "LemonadeMarket",
    name: "Market",  // the object's name
    weatherState: WeatherStateEL.PARTLY_CLOUDY,
    temperature: 25
  }
};

sim.scenario.initialState.events = [
  {typeName: "StartOfDay", occTime: 8, company: 1},
  {typeName: "EndOfDay", occTime: 18, company: 1}
];
/*******************************************************
 Define Output Statistics Variables
 ********************************************************/
sim.model.statistics = {
  // total profit
  "totalRevenue": {range: "Integer", label: "totalRevenue", initialValue: 0},
  // total profit
  "totalProfit": {range: "Integer", label: "totalProfit", initialValue: 0},
  // lost customer
  "lostSales": {range: "NonNegativeInteger", label: "Lost", initialValue: 0}
};
/*******************************************************
 Define User Interactions
 ********************************************************/
sim.scenario.userInteractions = {
  "StartOfDay": {  // triggering event type
    title: "Plan production and sales price (at StartOfDay)",
    // a UI may be triggered by an event satisfying a condition
    trigEvtCondition: function (e) {
      return (e.company.id === 1);
    },
    outputFields: {
      "dailyDemandHistory": {label:"Demand history (cups)",
        hint:"How many cups of lemonade have been sold in the past days",
        // defining the value of an output field
        fieldValue: function () {
          // objects have a value history for properties with a 'historySize' setting
          return sim.namedObjects["LemonadeStand"].history.dailyDemandQuantity.toString();
        }
      },
      "dailyRevenueHistory": {label:"Revenue history ($)",
        hint:"How much cash has been earned in the past days",
        fieldValue: function () {
          return sim.namedObjects["LemonadeStand"].history.dailyRevenue.toString();
        }
      },
      "weatherStateHistory": {label:"Weather history",
        hint:"How the weather was in the past days",
        fieldValue: function () {
          return sim.namedObjects["Market"].history.weatherState.toString();
        }
      },
      "temperatureHistory": {label:"Temperature history (°C)",
        hint:"How the temperature was in the past days",
        fieldValue: function () {
          return sim.namedObjects["Market"].history.temperature.toString();
        }
      },
      "forecastWeatherState": {label:"Weather forecast",
        hint:"The weather forecast for today",
        fieldValue: function () {
          return WeatherStateEL.labels[sim.namedObjects["Market"].forecastWeatherState-1];
        }
      },
      "forecastTemperature": {label:"Temperature forecast",
        hint:"The temperature forecast for today",
        fieldValue: function () {
          return sim.namedObjects["Market"].forecastTemperature.toString();
        }
      }
    },
    inputFields: {
      "planProdQty": {range:"PositiveInteger", default: 12, label:"Planned prod. quantity",
        hint:"How many pitchers of lemonade to produce?", suffixLabel:"pitchers (3.5 l)"},
      "planSalesPrice": {range:"Amount", decimalPlaces: 2, default: 2.00, label:"Planned sales price ($)",
        hint:"For how many $ is a cup to be sold?", suffixLabel:"per cup"}
    },
    // a list of fields or field groups (sub-arrays) defining the ordering/grouping of UI fields
    fieldOrder: ["dailyDemandHistory","dailyRevenueHistory","weatherStateHistory","temperatureHistory",
        ["forecastWeatherState","forecastTemperature"],"planProdQty","planSalesPrice"],
    waitForUserInput: true,
  }
};
/*******************************************************
 Define the observation UI
 ********************************************************/
sim.scenario.observationUI.type = "SVG";
sim.scenario.observationUI.canvas.width = 600;
sim.scenario.observationUI.canvas.height = 300;
//Allows background styling (not needed here)
//sim.scenario.observationUI.canvas.style = "background-color:yellow";
sim.scenario.observationUI.fixedElements = {
  "LemonadeStandTable": {
    shapeName: "polygon",  // an SVG shape name
    shapeAttributes: {points: "400,150 400,160 350,160 350,260 340,260 340,160 240,160 240,260 230,260 230,160 180,160 180,150"},
    style: "fill:brown; stroke-width:0"  // CSS style rules for the SVG element
  },
  "LemonadePitcher": {
    shapeName: "polyline",
    shapeAttributes: {points: "200,100 200,150 250,150 250,100"},
    style: "fill:none; stroke:black; stroke-width:3"
  }
};
sim.scenario.observationUI.objectViews = {
  "LemonadeStand": [  // a view consisting of a group of SVG elements
    {shapeName: "rect",  // an SVG shape name
     style: "fill:yellow; stroke-width:0",  // CSS style rules for the SVG element
     // slots for the attributes of an SVG shape with fixed value or an expression
     shapeAttributes: { x: 205, width: 40,
       y: function (stand) {return 145 - stand.productType.stockQuantity;},
       height: function (stand) {return stand.productType.stockQuantity;}
     }
    },
    {shapeName: "rect", fillPatternImage:{id:"fp1", file:"Dollar-Coin.svg"}, style:"stroke-width:0",
     shapeAttributes: { x: 300, width: 60,
       y: function (stand) {return 145 - parseInt( stand.amountOfCash / 10);},
       height: function (stand) {return parseInt( stand.amountOfCash / 10);}
     }
    },
    {shapeName: "text", shapeAttributes: {x: 225, y: 145,
     textContent: function (stand) {return stand.productType.stockQuantity;}},
     style:"font-size:10px; text-anchor:middle"
    }
  ],
  "Market": {  // a view consisting of a map of enum attributes to lists of visualization items with an optional canvasBackgroundColor
    "weatherState": [  // an array list mapping enum indexes to visualization items
      {shapeName:"image", shapeAttributes:{ file:"icons8-Summer-96.png",
          x:450, y:0, width:96, height:96}, canvasBackgroundColor:"lightyellow"},
      {shapeName:"image", shapeAttributes:{ file:"icons8-Partly-Cloudy-Day-96.png",
          x:450, y:0, width:96, height:96}, canvasBackgroundColor:"oldlace"},  // or ivory?
      {shapeName:"image", shapeAttributes:{ file:"icons8-Cloud-128.png",
          x:450, y:0, width:128, height:128}, canvasBackgroundColor:"lightgray"},
      {shapeName:"image", shapeAttributes:{ file:"icons8-Rain-128.png",
          x:450, y:0, width:128, height:128}, canvasBackgroundColor:"silver"},
    ]
  }
};
sim.scenario.observationUI.eventAppearances = {
  /* duration  If the sound source is a file and if no duration is specified, then the entire file is played.
               If deal with a sound file and a duration is specified with a value lower than the sound file duration
               then only the "duration" time is played from that file. If the source is a note sequence and no duration
               is specified, then the duration is computed as the sum of all note durations. If the source is a
               note sequence and a duration is defined then the duration of each note from sequence is multiplied
               with a factor that ensures that the total notes duration equals with the value of the @duration attribute.
   soundSource The source can be a note sequence or a sound file (identified by its extension (.mp3 or ...).
               If it's a file it is first searched in the project directory under "media/sounds". If the file is not found,
               then it is searched in the global media/sounds folder. If still not found, then no sound is played.
               Note that the path is relativ to "media/sounds". So a value @introSoundFile="/mySounds/background.mid"
               will be searched in "media/sounds/mySounds/background.mid".
               A note sequence is a list of note/duration/volume triples where the note is an integer between 0
               (corresponding to a low C) and 127 (in half-tones) and the duration (in ms) and volume (in range 0 = mute
               to 127 = MAX_VOLUME) are positive integers. An example is "12/300/80 14/200/90"
   instrumentNo (or instrumentName) ???
   */
  "DailyDemand": {
    //sound: {duration: 1000, source:"12/300/80 14/200/90"},
    view: {  // an event view is a web animation of a DOM element
      imageFile: "customers.svg",
      style: "width:300px; height:300px; position:absolute; left:-30%; top:135px;",
      keyframes: [{left:'-30%'}, {left:'80%'}],
      duration: 1000,  // ms
      //iterations: Infinity,
      //fill:
    }
  },
  "EndOfDay": {
    view: {  // an event view is a web animation of a DOM element
      domElem: function () {return sim.visualEl;},  // the visualization container element
      keyframes: [{backgroundColor:'lightgray'}, {backgroundColor:'darkslategrey'}],
      duration: 1000  // ms
    }
  }
};
