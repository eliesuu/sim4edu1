var WeatherStateEL = new eNUMERATION( "WeatherStateEL",
    ["sunny", "partly cloudy", "cloudy", "rainy"] );

var LemonadeMarket = new cLASS({
  Name: "LemonadeMarket",
  supertypeName: "oBJECT",
  properties: {
    "weatherState": {
      range: WeatherStateEL,
      label: "Weather conditions",
      shortLabel: "cond",
      historySize: 5,
      initialValue: 2
    },
    "temperature": {
      range: "Decimal",
      decimalPlaces: 1,
      label: "Temperature",
      shortLabel: "temp",
      historySize: 5,
      initialValue: 24
    },
    "forecastWeatherState": {
      range: WeatherStateEL,
      label: "Weather state forecasting",
      initialValue: 2
    },
    "forecastTemperature": {
      range: "Decimal",
      label: "Temperature forecasting",
      initialValue: 25
    }
  },
  methods: {
    "updateWeather": function() {
      var r = rand.uniformInt( 0, 99),
          newWeatherState = this.weatherState,
          newTemperature = this.temperature;
      
      // Update Weather State
      switch (this.weatherState) {
        case WeatherStateEL.SUNNY:
          if (r < 50) {
            newWeatherState = WeatherStateEL.SUNNY;
          } else {
            newWeatherState = WeatherStateEL.PARTLY_CLOUDY;
          }
          break;
        case WeatherStateEL.PARTLY_CLOUDY:
          if (r < 25) {
            newWeatherState =  WeatherStateEL.SUNNY;
          } else if (r < 75) {
            newWeatherState = WeatherStateEL.PARTLY_CLOUDY;
          } else {
            newWeatherState = WeatherStateEL.CLOUDY;
          }
          break;
        case WeatherStateEL.CLOUDY:
          if (r < 25) {
            newWeatherState = WeatherStateEL.PARTLY_CLOUDY;
          } else if (r < 75) {
            newWeatherState = WeatherStateEL.CLOUDY;
          } else {
            newWeatherState = WeatherStateEL.RAINY;
          }
          break;
        case WeatherStateEL.RAINY:
          if (r < 50) {
            newWeatherState = WeatherStateEL.CLOUDY;
          } else {
            newWeatherState = WeatherStateEL.RAINY;
          }
          break;
      }
      this.history.weatherState.add( this.weatherState);
      this.weatherState = newWeatherState;

      // Update Temperature
      switch (this.weatherState) {
        case WeatherStateEL.SUNNY:
          newTemperature += rand.uniformInt( 1, 2);
          break;
        case WeatherStateEL.PARTLY_CLOUDY:
          newTemperature += rand.uniformInt( -1, 1);
          break;
        case WeatherStateEL.CLOUDY:
          newTemperature -= rand.uniformInt( 1, 2);
          break;
        case WeatherStateEL.RAINY:
          newTemperature -= rand.uniformInt( 2, 3);
          break;
      }
      newTemperature = Math.max( 20, newTemperature);
      newTemperature = Math.min( newTemperature, 35);
      this.history.temperature.add( this.temperature);
      this.temperature = newTemperature;
    },
    "forecastWeather": function () {
      // forecast weather state and temperature for the demand period
      var r = rand.uniformInt( 0, 99),
          forecastState=0, forecastTemp=0;
      // Forecast Weather State
      switch (this.weatherState) {
        case WeatherStateEL.SUNNY:
          if (r < 68) {
            forecastState = WeatherStateEL.SUNNY;
          } else if (r < 92) {
            forecastState = WeatherStateEL.PARTLY_CLOUDY;
          } else {
            forecastState = WeatherStateEL.CLOUDY;
          }
          break;
        case WeatherStateEL.PARTLY_CLOUDY:
          if (r < 20) {
            forecastState =  WeatherStateEL.SUNNY;
          } else if (r < 75) {
            forecastState = WeatherStateEL.PARTLY_CLOUDY;
          } else if (r < 94) {
            forecastState = WeatherStateEL.CLOUDY;
          } else {
            forecastState = WeatherStateEL.RAINY;
          }
          break;
        case WeatherStateEL.CLOUDY:
          if (r < 3) {
            forecastState = WeatherStateEL.SUNNY;
          } else if (r < 22) {
            forecastState = WeatherStateEL.PARTLY_CLOUDY;
          } else if (r < 78) {
            forecastState = WeatherStateEL.CLOUDY;
          } else {
            forecastState = WeatherStateEL.RAINY;
          }
          break;
        case WeatherStateEL.RAINY:
          if (r < 68) {
            forecastState = WeatherStateEL.RAINY;
          } else if (r < 98) {
            forecastState = WeatherStateEL.CLOUDY;
          } else {
            forecastState = WeatherStateEL.PARTLY_CLOUDY;
          }
          break;
      }
      this.forecastWeatherState = forecastState;

      switch (forecastState) {
        case WeatherStateEL.SUNNY:
          forecastTemp = rand.uniformInt( Math.floor(this.temperature + 1),
              Math.floor(this.temperature + 2));
          break;
        case WeatherStateEL.PARTLY_CLOUDY:
          forecastTemp = rand.uniformInt( Math.floor(this.temperature - 1),
              Math.floor(this.temperature + 1));
          break;
        case WeatherStateEL.CLOUDY:
          forecastTemp = rand.uniformInt( Math.floor(this.temperature - 2),
              Math.floor(this.temperature - 1));
          break;
        case WeatherStateEL.RAINY:
          forecastTemp = rand.uniformInt( Math.floor(this.temperature - 3),
              Math.floor(this.temperature - 2));
          break;
      }
      this.forecastTemperature = forecastTemp;
    }
  }
});