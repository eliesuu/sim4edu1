/*******************************************************************************
 * The Delivery event class
 *
 * @copyright Copyright
 * @license The MIT License (MIT)
 * @author Ke
 ******************************************************************************/
var Delivery = new cLASS({
  Name: "Delivery",
  shortLabel: "Del",
  supertypeName: "eVENT",
  properties: {
      "receiver": {range: "SingleProductCompany"}
  },
  methods: {
    "onEvent": function () {
      var events=[], cost=0,
          replenishmentOrder = this.receiver.computeReplenishmentOrder();
      // quantity = batch: adding in stock
      this.receiver.performProduction();
      // calculate cost of replenishment order
      Object.keys( this.receiver.inputInventoryItems).forEach(function (inpItemName) {
          var inpItem = sim.namedObjects[inpItemName];
          cost += (Math.ceil(replenishmentOrder[inpItem.name] /
              inpItem.quantityPerSupplyUnit)) * inpItem.purchasePrice;
      });
      // replenishment cost + production cost
      cost += this.receiver.productType.productionCost;
      sim.stat.totalProfit -= cost;  //TODO: compute profit only at end of day
      this.receiver.amountOfCash -= cost;

      events.push(new DailyDemand({
        occTime: this.occTime + 6,  // 6 hours later
        company: this.receiver,
        quantity: DailyDemand.sampleQuantity()
      }));
      return events;
    }
  }
});
