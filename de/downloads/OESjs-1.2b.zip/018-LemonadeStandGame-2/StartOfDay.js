/*******************************************************************************
 * The StartOfDay event class
 *
 * @copyright Copyright
 * @license The MIT License (MIT)
 * @author Ke
 ******************************************************************************/
var StartOfDay = new cLASS( {
  Name: "StartOfDay",
  shortLabel: "SoD",
  supertypeName: "eVENT",
  
  properties: {
    "company": {
      range: "SingleProductCompany"
    }
  },
  
  methods: {
    // parameters may be delivered by user action form
    "onEvent": function (slots) {
      var events=[];
      //TODO: this is just a quick and dirty way to update the weather
      sim.namedObjects["Market"].updateWeather();
      sim.namedObjects["Market"].forecastWeather();
      // production planning
      this.company.productType.plannedProductionQuantity = (slots && slots.planProdQty) ?
          slots.planProdQty : this.company.getPlannedProductionQuantity();
      // sales price planning
      this.company.productType.salesPrice = (slots && slots.planSalesPrice) ?
          slots.planSalesPrice : this.company.getSalesPrice();
      events.push( new Delivery({
          occTime: this.occTime + 2,  // 2 hours later
          receiver: this.company
        })
	  );
      return events;
    }
  }
} );
// Any exogenous event type needs to define a static function "recurrence"
StartOfDay.recurrence = function () {
  return 24;
};
// Any exogenous event type needs to define a static function "createNextEvent"
StartOfDay.createNextEvent = function ( e ) {
  return new StartOfDay( {
    occTime: e.occTime + StartOfDay.recurrence(),
    company: e.company
  } );
};