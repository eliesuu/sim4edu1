var OutputItemType = new cLASS( {
  Name: "OutputItemType",
  supertypeName: "ItemType",
  properties: {
    "salesPrice": {range: "PositiveDecimal", label: "Sales price"},
    "batchSize": {range: "PositiveDecimal", label: "Batch size"},  // in quantity units
    "productionCost": {range: "PositiveDecimal", initialValue: 10,
      label: "Production cost"
    },
    "stockQuantity": {range: "Decimal",  // in quantity units
        label: "Stock quantity", shortLabel: "qty"},
    "bomItemsPerBatch": {range: Object, label: "Bill of materials"},
    // a non-persistent variable
    "plannedProductionQuantity": {range: "Integer"} // in number of batches
  }
} );