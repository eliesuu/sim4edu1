/*******************************************************************************
 * The DailyDemand event class
 *
 * @copyright Copyright
 * @license The MIT License (MIT)
 * @author Ke
 ******************************************************************************/
var DailyDemand = new cLASS({
    Name: "DailyDemand",
    shortLabel: "Dem",
    supertypeName: "eVENT",

    properties: {
      "company": {
        range: "SingleProductCompany"
      },
      "quantity": {  // in product quantity units (e.g., lemonade cups)
        range: "PositiveInteger",
        label: "Quantity",
        shortLabel: "quant"
      }
    },

    methods: {
      "onEvent": function () {
        var events = [],
            qtyPerSupplyUnit = this.company.productType.quantityPerSupplyUnit,
            q = this.quantity * qtyPerSupplyUnit,
            stockLevel = this.company.productType.stockQuantity,
            revenue = 0;
        // deduct demand from quantity in stock
        if (q > stockLevel) {
          this.company.productType.stockQuantity = 0;
          sim.stat.lostSales += q - stockLevel;
        } else {
          this.company.productType.stockQuantity = stockLevel - q;
        }
        // Calculate profit and total amountOfCash
        revenue = Math.floor( Math.min( q, stockLevel) / qtyPerSupplyUnit)
            * this.company.productType.salesPrice;
        //console.log("Dem (lit): "+ q + ", Stock: "+ stockLevel +", Rev: "+ revenue);
        sim.stat.totalRevenue += revenue;
        this.company.amountOfCash += revenue;
        // store history values in manuf. company
        this.company.history.dailyDemandQuantity.add( this.quantity);
        this.company.history.dailyRevenue.add( revenue);
        return events;
      }
    }
});
DailyDemand.sampleQuantity = function () {
  // in product quantity units (e.g., lemonade cups)
  return rand.uniformInt(50, 100);  //
};