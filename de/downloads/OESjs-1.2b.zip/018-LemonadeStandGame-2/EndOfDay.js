/*******************************************************************************
 * The EndOfDay event class
 *
 * @copyright Copyright
 * @license The MIT License (MIT)
 * @author Ke
 ******************************************************************************/
var EndOfDay = new cLASS( {
  Name: "EndOfDay",
  shortLabel: "EoD",
  supertypeName: "eVENT",
  
  properties: {
    "company": {
      range: "SingleProductCompany"
    }
  },
  
  methods: {
    "onEvent": function () {
      var cost = 0,
          material,
          prodName,
          input = this.company.inputInventoryItems;
      // update stockQuantity
      this.company.productType.stockQuantity = 0;
      this.company.inputInventoryItems["IceCubes"] = 0;
	  sim.stat.totalRevenue = this.company.amountOfCash;
      
      // calculate inventory cost
        /*Object.keys(this.company.inputInventoryItems).forEach( function (inpItemName) {
            material = sim.namedObjects[inpItemName];
            prodName = material.name;
            console.log("name:" + " " + prodName);
            cost += (input[prodName] /
                material.quantityPerSupplyUnit ) * material.inventoryCost;
            console.log("cost for inventory:" + " " + cost);
        });

      sim.stat.totalProfit -= cost;
      this.company.amountOfCash -= cost;
      */
      return [];
    }
  }
} );
// Any exogenous event type needs to define a static function "recurrence"
EndOfDay.recurrence = function () {
  return 24;
};
// Any exogenous event type needs to define a static function "createNextEvent"
EndOfDay.createNextEvent = function ( e ) {
  return new EndOfDay( {
    occTime: e.occTime + EndOfDay.recurrence(),
    company: e.company
  } );
};