var SingleProductCompany = new cLASS({
  Name: "SingleProductCompany",
  supertypeName: "oBJECT",
  properties: {
    "productType": {
      range: "OutputItemType"
    },
    "inputInventoryItems": {
      range: Object,
      label: "Input inventory items",
      shortLabel: "inputs"
    },
    "amountOfCash": {
      range: "NonNegativeInteger",
      initialValue: 500,
      label: "Amount of cash",
      shortLabel: "cash"
    },
    "dailyDemandQuantity": {
      range: "PositiveInteger",
      historySize: 5
    },
    "dailyRevenue": {
      range: "PositiveDecimal",
      decimalPlaces: 2,
      historySize: 5
    },
    "currentReplenishmentOrder": {  //TODO: check if needed
      range: Object
    }
  },
  methods: {
    "getDemandForecast": function () {
        return rand.uniformInt( 50, 100);
    },
    "getPlannedProductionQuantity": function () {
        var demandForecast = this.getDemandForecast();
        return Math.ceil((demandForecast *
            this.productType.quantityPerSupplyUnit) /
            this.productType.batchSize);
    },
    // replenishment using periodic fill-up reorder policy
    "computeReplenishmentOrder": function () {
        var replenishmentOrder = {},
            inputInvItems = this.inputInventoryItems;
        Object.keys( inputInvItems).forEach(function (inpItemName) {
            var inpItem = sim.namedObjects[inpItemName];
            replenishmentOrder[inpItemName] = inpItem.targetInventory -
                inputInvItems[inpItemName];
        });
        return replenishmentOrder;
    },
    "getSalesPrice": function () {
        //return this.productType.salesPrice;
        var price,
            lemonadeCostPerBottle = 0,
            r,
            expectProfitRate = 0.1,
            quantity = this.performProduction(),
            material,
            prodType = this.productType;
        Object.keys(this.inputInventoryItems).forEach(function (inpItemName) {
            material = sim.namedObjects[inpItemName];
            lemonadeCostPerBottle += ((material.purchasePrice / material.quantityPerSupplyUnit) *
                prodType.bomItemsPerBatch[inpItemName]) /
                (prodType.batchSize / prodType.quantityPerSupplyUnit);
        });
        //profit rate
        r = ((this.amountOfCash * expectProfitRate) + prodType.productionCost) /
            ((quantity * prodType.batchSize / prodType.quantityPerSupplyUnit) *
            lemonadeCostPerBottle);
        //price = Math.ceil(lemonadeCostPerBottle * (1 + expectProfitRate));
        price = lemonadeCostPerBottle * (1 + r);
        price = price.toFixed(1);
        return price;
    },
    // get the executable quantity into production phase
    "performProduction": function () {
        var prodType = this.productType,
            outputProdQuantity = prodType.plannedProductionQuantity,
            input = this.inputInventoryItems,
            replenishmentOrder = this.computeReplenishmentOrder();

        Object.keys(this.inputInventoryItems).forEach(function (item) {
            input[item] += replenishmentOrder[item];
            outputProdQuantity = Math.min(outputProdQuantity,
                (input[item] / prodType.bomItemsPerBatch[item]));
        });

        // Reduce the inventory items, but firstly add the quantity from
        // replenishment order that represent replenishment received before
        // production
        Object.keys(this.inputInventoryItems).forEach(function (item) {
            input[item] -= (outputProdQuantity * prodType.bomItemsPerBatch[item]);
        });
        this.inputInventoryItems = input;

        // Calculate the customer quantity
        this.productType.stockQuantity = outputProdQuantity *
            this.productType.batchSize;

        // finely the unit of outputProdQuantity is batch
        return outputProdQuantity;
    }
  }
});
